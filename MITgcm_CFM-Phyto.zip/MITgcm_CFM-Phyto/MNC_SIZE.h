C $Header: /u/gcmpack/MITgcm/pkg/mnc/MNC_SIZE.h,v 1.9 2008/06/23 20:52:58 utke Exp $
C $Name:  $
C

      integer MNC_MAX_ID, MNC_MAX_FID
      integer MNC_MAX_CHAR, MNC_MAX_CATT
      integer MNC_MAX_PATH, MNC_MAX_INFO
      integer MNC_CW_MAX_I, MNC_CW_CVDAT
      parameter ( MNC_MAX_ID   =  50000 )
      parameter ( MNC_MAX_FID  =   5000 )
      parameter ( MNC_MAX_CHAR =     40 )
      parameter ( MNC_MAX_CATT =    100 )
      parameter ( MNC_MAX_PATH =    500 )
      parameter ( MNC_MAX_INFO =   3000 )
      parameter ( MNC_CW_MAX_I =     20 )
      parameter ( MNC_CW_CVDAT =  50000 )

CEH3 ;;; Local Variables: ***
CEH3 ;;; mode:fortran ***
CEH3 ;;; End: ***
